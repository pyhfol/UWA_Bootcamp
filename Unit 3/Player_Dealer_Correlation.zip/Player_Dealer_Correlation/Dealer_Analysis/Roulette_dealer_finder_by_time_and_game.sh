#!/bin/bash
date=$1
time=$2
hour=${time:0:5}
ampm=${time: -2}
time=$hour":00 "$ampm
game=$3

case $game in
1|Blackjack|"Black Jack"|BlackJack)
echo
echo "Blackjack Dealer on $date"
cat $1_Dealer_schedule | grep "$time" | awk -F'[\t ]' '{print $1,$2,$3,$4}'
;;
2|Roulette)
echo
echo "Roulette Dealer on $date"
cat $1_Dealer_schedule | grep "$time" | awk -F'[\t ]' '{print $1,$2,$5,$6}'
;;
3|"Texas Holdem"|Texas|Holdem)
echo
echo "Texas Holdem Dealer on $date"
cat $1_Dealer_schedule | grep "$time" | awk -F'[\t ]' '{print $1,$2,$7,$8}'
;;
*)
echo "Invalid game requested"
esac

#!/bin/bash
time=$2
hour=${time:0:5}
ampm=${time: -2}
time=$hour":00 "$ampm
cat $1_Dealer_schedule | grep "$time" | awk -F'[\t ]' '{print $1,$2,$5,$6}'

#!/bin/bash

cat 0312_Dealer_schedule | grep "02:00:00 PM" | awk -F'[\t ]' '{print $1,$2,$5,$6}'
